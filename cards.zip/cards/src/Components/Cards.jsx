import React, { useEffect, useState } from 'react';
import { getData } from '../services/userService';

function Cards() {
    const [cardsData, setCardsData] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const cardsPerPage = 8;

    useEffect(() => {
        const fetchData = async () => {
            try {
                const data = await getData();
                console.log(data);
                setCardsData(data || []);
            } catch (error) {
                console.error("Failed to fetch cards data:", error);
            }
        };

        fetchData();
    }, []);

    const indexOfLastCard = currentPage * cardsPerPage;
    const indexOfFirstCard = indexOfLastCard - cardsPerPage;
    const currentCards = cardsData.slice(indexOfFirstCard, indexOfLastCard);

    const totalPages = Math.ceil(cardsData.length / cardsPerPage);

    const nextPage = () => {
        if (currentPage < totalPages) setCurrentPage(prev => prev + 1);
    };

    const prevPage = () => {
        if (currentPage > 1) setCurrentPage(prev => prev - 1);
    };

    return (
        <>
            <div className='w-full py-[4rem] px-4 bg-white' style={{ backgroundColor: '#0D051F' }}>
                <div className='max-w-[1240px] mx-auto grid md:grid-cols-4 gap-4'>
                    {currentCards.map((item, index) => (
                        <div
                            key={index}
                            className='w-full shadow-xl flex flex-col items-center p-6 my-4 rounded-lg hover:scale-105 duration-300 bg-blue-500'
                        >
                         
                            <img
                                src={item?.Image[0] ? item.Image : 'src/assets/img.png'}
                                alt="Card Image"
                                className='w-[150px] h-[150px] object-cover rounded mb-4'
                            />

                            {/* Title */}
                            <h2 className='text-2xl font-bold text-center py-2 text-white'>
                                {item?.Title || 'No Title'}
                            </h2>

                            {/* Status button */}
                            <button className="w-full bg-white text-xl rounded-lg font-bold mt-4 py-2">
                                {item?.Status || 'No Status'}
                            </button>
                        </div>
                    ))}
                </div>

                <div className="flex justify-center items-center mt-8 space-x-4 w-full">
                    <button
                        onClick={prevPage}
                        disabled={currentPage === 1}
                        className='bg-gray-300 text-black px-4 py-2 rounded disabled:opacity-50'
                    >
                        Previous
                    </button>
                    <progress id="file" value={currentPage} max={totalPages}> 32% </progress>
                    <button
                        onClick={nextPage}
                        disabled={currentPage === totalPages}
                        className='bg-gray-300 text-black px-4 py-2 rounded disabled:opacity-50'
                    >
                        Next
                    </button>
                </div>
            </div>
        </>
    );
}

export default Cards;
